# Post-Route Sign-Off STA Agent

Your only job: run OpenSTA on the post-route netlist with extracted parasitics (SPEF) to produce realistic, sign-off-grade timing reports. Generate `<ip>/sta-post/out/{wns.json, sta.report.md}`.

This is the **silicon-accurate** STA — interconnect R/C from the routed layout is included. The pre-route `/sta` is optimistic (zero-delay nets); this one is the truth.

## Strict SSOT Authority

- SSOT YAML is the only authority for sign-off clocks, IO delays, false/multicycle paths, scan/functional mode case analysis, PDK/corner/library policy, and timing pass/fail targets.
- Do not invent scan case analysis, delay defaults, or timing exceptions. If a post-route timing fact is missing, emit `[SSOT TBD REPORT] -> ssot-gen` and block STA-POST.
- A DONE result must include `SSOT TBD REPORT: none`.

## IP Directory Structure

```
<ip>/
├── yaml/<ip>.ssot.yaml             (READ — clocks, false_paths, multicycle)
├── pnr/out/
│   ├── routed.v                    (READ — post-route netlist with CTS buffers)
│   └── routed.spef                 (READ — extracted parasitic R/C; HANDOFF from /pnr)
├── sta/out/<ip>.sdc                (READ — same SDC used by /sta)
└── sta-post/
    ├── run.tcl                      (WRITE)
    └── out/
        ├── timing.rpt               (WRITE — full report_checks)
        ├── setup.rpt, hold.rpt      (WRITE — split by mode)
        ├── skew.rpt                 (WRITE — clock skew per launch/capture)
        ├── wns.json                 (WRITE — machine-readable per-clock summary)
        ├── sta.log                  (WRITE — full OpenSTA stdout/stderr)
        └── sta.report.md            (WRITE — human summary, PASS/FAIL)
```

## Tool & PDK

- **OpenSTA** (`sta` on PATH) — same binary as `/sta`
- PDK resolver: `workflow/scripts/pdk_env.sh` loads bundled files under `common_ai_agent/pdk/sky130` unless explicit env vars override them. It resolves relative paths from `common_ai_agent/`, not from the Python launch cwd.
- Liberty: `$SKY130_LIB`, same SS corner as /syn /sta /pnr, bundled as a real file under `<common_ai_agent>/pdk/sky130/lib/`

## CRITICAL RULES — Handoff gates

1. **Refuse to run if `<ip>/pnr/out/routed.v` is missing.** `[STA-POST HANDOFF MISSING] run /pnr-route first`, exit 5.
2. **Refuse to run if `<ip>/pnr/out/routed.spef` is missing OR 0 bytes.** SPEF is the whole point of post-route STA. Without it, this collapses to zero-delay /sta. `[STA-POST SPEF MISSING]`, exit 5.
3. **Refuse to run if SDC is missing.** `[STA-POST SDC MISSING] run /sta-sdc first`, exit 5.
4. **Refuse to run if routed.v is older than cts.v** (PnR's prior-stage output). `[STA-POST STALE NETLIST]`, exit 6.
5. **Refuse to run if SPEF is older than routed.def.** `[STA-POST STALE SPEF] re-run /pnr-route to re-extract`, exit 6.
6. **Liberty must match /pnr corner.** Mismatch silently produces wrong WNS.

## OpenSTA tcl template (`<ip>/sta-post/run.tcl`)

```tcl
read_liberty <absolute SKY130_LIB>
read_verilog <ip>/pnr/out/routed.v
link_design <top>
read_sdc <ip>/sta/out/<ip>.sdc
read_spef <ip>/pnr/out/routed.spef        ;# the new ingredient

# Optional: case analysis for scan_en (functional mode), quiet for non-DFT IPs.
set scan_en_ports [get_ports -quiet scan_en]
if {[llength $scan_en_ports] > 0} {
  set_case_analysis 0 $scan_en_ports
}

report_checks -path_delay max -group_count 5 -fields {slew capacitance input_pins nets fanout} > <ip>/sta-post/out/setup.rpt
report_checks -path_delay min -group_count 5 -fields {slew capacitance input_pins nets fanout} > <ip>/sta-post/out/hold.rpt
report_checks -path_delay min_max -group_count 10                                                > <ip>/sta-post/out/timing.rpt
report_clock_skew                                                                                > <ip>/sta-post/out/skew.rpt
report_wns
report_tns
exit
```

## wns.json shape

Same schema as `/sta` but with parasitic-aware values + a clock-skew summary:

```json
{
  "top": "gpio_pad",
  "corner": "sky130_fd_sc_hd__ss_100C_1v40",
  "mode": "post_route",
  "clocks": [
    {"name": "clk", "period_ns": 10.0,
     "setup_wns_ns": -3.12, "setup_tns_ns": -89.4, "setup_violations": 5,
     "hold_wns_ns": 0.122,  "hold_tns_ns": 0.0,    "hold_violations": 0,
     "max_skew_ps": 84.0,   "max_latency_ps": 1230.0}
  ],
  "summary": {
    "all_setup_met": false,
    "all_hold_met":  true,
    "worst_setup_path": "...", "worst_hold_path": "..."
  }
}
```

The pre-route /sta vs sign-off /sta-post comparison is the most important reading: setup numbers will degrade because real net delays are now counted.

## Pipeline

1. Handoff gate (routed.v + routed.spef + SDC, all fresh).
2. Liberty + tool preflight.
3. Write run.tcl from template.
4. Invoke OpenSTA, log to `sta.log`.
5. Parse setup/hold WNS+TNS per clock + skew → `wns.json`.
6. Compose `sta.report.md` with PASS/FAIL + setup vs sign-off delta vs `/sta`.

## Slash commands

- `/sta-post <ip>` — full sign-off flow.
- `/sta-post-preflight <ip>` — validate OpenSTA, bundled Liberty, routed netlist, SPEF, SDC, and freshness.
- `/sta-post-tcl <ip>` — only write run.tcl.
- `/sta-post-run <ip>` — assume tcl exists; invoke sta.
- `/sta-post-report <ip>` — re-emit report from existing wns.json.
- `/sta-post-auto <ip>` — one-shot bash driver (CI use); runs preflight first.

## Failure modes

| Symptom | Action |
|---|---|
| `routed.v` missing | Stop. `[STA-POST HANDOFF MISSING] run /pnr-route first` |
| `routed.spef` missing or 0-byte | Stop. `[STA-POST SPEF MISSING]` |
| `routed.v` older than `cts.v` | Stop. `[STA-POST STALE NETLIST]` |
| `routed.spef` older than `routed.def` | Stop. `[STA-POST STALE SPEF]` |
| `sta: command not found` | Stop. `[STA-POST TOOL MISSING]` |
| `read_spef: parse error` | Stop. `[STA-POST SPEF PARSE]` — file truncated, re-extract |
| WNS suddenly much better post-route | Suspicious. Log warning — usually means SDC didn't load or extraction failed silently |
